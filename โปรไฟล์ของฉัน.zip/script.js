src = "https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"
 src = "https://cdn.jsdelivr.net/npm/canvas-confetti@1.5.1/dist/confetti.browser.min.js" 
  document.getElementById("confetti-btn").addEventListener("click", () => {
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 }
    });
  });
  async function sendToDiscord(event) {
    event.preventDefault(); // ป้องกันการรีเฟรชหน้า

    const name = document.querySelector('input[name="name"]').value;
    const email = document.querySelector('input[name="email"]').value;
    const message = document.querySelector('textarea[name="message"]').value;

    const webhookURL = "https://discord.com/api/webhooks/1376904789790687353/g82h20jnVAOg2o7n4zSGE4c4eGcS9OLxdK6ivyQfhqtHxESXj6fIyvQARZ0dA8otcJeD"; // แทนที่ด้วย Webhook URL ของคุณ

    const payload = {
      content: `📩 **ข้อความใหม่จากฟอร์มเว็บไซต์**\n\n👤 ชื่อ: ${name}\n📧 อีเมล: ${email}\n📝 ข้อความ: ${message}`
    };

    try {
      const response = await fetch(webhookURL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        alert("ส่งข้อความเรียบร้อยแล้ว!");
      } else {
        alert("เกิดข้อผิดพลาดในการส่งข้อความ.");
      }
    } catch (error) {
      console.error("Error sending message to Discord:", error);
      alert("ไม่สามารถส่งข้อความได้.");
    }
  }